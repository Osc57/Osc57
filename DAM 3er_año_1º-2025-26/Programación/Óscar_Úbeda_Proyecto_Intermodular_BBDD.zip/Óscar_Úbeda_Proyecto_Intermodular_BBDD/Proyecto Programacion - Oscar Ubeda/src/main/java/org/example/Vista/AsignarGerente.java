package org.example.Vista;

import org.example.Modelo.Gerente;
import org.example.Modelo.Proyecto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import static org.example.ControladorDAO.GerenteDAO.*;
import static org.example.Utils.Funcionalidad.*;
import static org.example.Utils.Messages.mostrarMensaje;

public class AsignarGerente extends JFrame {

    private Proyecto proyecto;

    public AsignarGerente(Proyecto proyect) {
        this.proyecto = proyect;

        this.setTitle("Seleccione Gerente");
        this.setSize(570, 460);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                mostrarMensaje("⚠️ Debes completar la asignación antes de cerrar esta ventana.");
            }
        });

        JLabel introducirCliente = new JLabel("•Seleccione gerente para el proyecto");
        introducirCliente.setFont(FUENTE_TITULO_2);
        introducirCliente.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 0));

        JPanel panelScrollPanel = getJPanelScrollPanel();
        //JPanel panelBotonRetorno = getPanelBotonRetorno(this, new GestionEmpleado());

        this.add(introducirCliente, BorderLayout.NORTH);
        this.add(panelScrollPanel, BorderLayout.CENTER);
        //this.add(panelBotonRetorno, BorderLayout.SOUTH);
    }

    private JPanel getJPanelScrollPanel() {
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(0, 15, 15, 15));

        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.CENTER));

        configurarListaEnScroll(LISTA_GERENTE);

        JScrollPane jScrollPane = new JScrollPane(LISTA_GERENTE);
        jScrollPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 5));

        MODEL_GERENTE.removeAllElements();

        ArrayList<Gerente> empleados = mostrarGerentes();
        for (Gerente t : empleados) {
            MODEL_GERENTE.addElement(t);
        }

        JButton btnSeleccionEmple = crearEstiloBotonSubmit("SELECCIONAR GERENTE");
        btnSeleccionEmple.setPreferredSize(new Dimension(515, 45));

        btnSeleccionEmple.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Gerente seleccionados = LISTA_GERENTE.getSelectedValue();

                if (seleccionados == null) {
                    mostrarMensaje("⚠️ Seleccione una opción");
                    return;
                }

                Gerente gerenteSeleccionado = obtenerDatosGerente(seleccionados);

                if (saberSiGerenteEstaEnProyecto(gerenteSeleccionado)) {
                    int respuesta = JOptionPane.showConfirmDialog(
                            null,
                            "⚠️ " + gerenteSeleccionado.getDni() + " " + gerenteSeleccionado.getNombre() + " Esta asignado a un proyecto\n" +
                                    "¿Quieres asignarlo también a este proyecto?",
                            "Asignar Programador",
                            JOptionPane.YES_NO_OPTION
                    );

                    if (respuesta != JOptionPane.YES_OPTION) {
                        // Usuario dijo NO → no asignar y no avanzar
                        return;
                    }
                }

                if (asignarGerenteProyecto(gerenteSeleccionado, proyecto)) {
                    mostrarMensaje("✅ Proyecto creado y asignado correctamente");

                    new GestionProyectos().setVisible(true);
                    dispose();
                } else {
                    mostrarMensaje("❌ Error al asignar el gerente");
                }

            }
        });

        panelBoton.add(btnSeleccionEmple);

        panelPrincipal.add(jScrollPane, BorderLayout.CENTER);
        panelPrincipal.add(panelBoton, BorderLayout.SOUTH);

        return panelPrincipal;
    }
}

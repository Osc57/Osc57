# Curso de Vue 3 - Component API

## [ 1 - Fundamentos de Vue ](1-Fundamentos.md)
## [ 2 - Componentes ](2-Componentes.md)
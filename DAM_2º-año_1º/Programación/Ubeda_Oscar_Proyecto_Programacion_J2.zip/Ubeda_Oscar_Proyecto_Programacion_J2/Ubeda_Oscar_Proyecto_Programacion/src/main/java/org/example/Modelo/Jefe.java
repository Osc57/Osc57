package org.example.Modelo;

public class Jefe extends Trabajador {
    public Jefe() {
    }

    public Jefe(String dni, String nombre, String apellidos, int telefono) {
        super(dni, nombre, apellidos, telefono);
    }
}

package org.example.Modelo;

public class Recepcionista extends Trabajador {
    public Recepcionista() {
    }

    public Recepcionista(String dni, String nombre, String apellidos, int telefono) {
        super(dni, nombre, apellidos, telefono);
    }
}

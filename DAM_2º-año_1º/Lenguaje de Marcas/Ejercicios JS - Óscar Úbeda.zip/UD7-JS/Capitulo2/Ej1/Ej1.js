let celsius = prompt("Escribe la temperatura en grados Celsius: ")

let faren = (celsius * (9/5) + 32)

console.log(`${celsius}ºC son ${faren}ºF`)
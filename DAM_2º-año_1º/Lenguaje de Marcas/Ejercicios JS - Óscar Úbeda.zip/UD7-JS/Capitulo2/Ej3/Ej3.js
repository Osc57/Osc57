let precioProducto = prompt("Dime el precio del producto que quieres comprar: ")

let cantidad = prompt("Cuantas unidades quieres del producto: ")

let precioTotal = precioProducto*cantidad

console.log(`El precio total es ${precioTotal}`)
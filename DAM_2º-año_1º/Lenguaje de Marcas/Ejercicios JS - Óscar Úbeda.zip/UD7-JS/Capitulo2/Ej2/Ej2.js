let minutos = prompt("Dime los minutos para sacar la hora: ")

let horas = minutos/60

console.log(`${minutos} minutos son ${horas} horas`)
function filtrarPares(n){
    return n.filter(function(n){
        return n% 2 === 0;
    });
}
